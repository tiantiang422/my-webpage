import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";

const root = path.resolve(import.meta.dirname, "..");
const required = ["index.html", "css/style.css", "js/app.js", "js/content.js", "README.md", "assets"];
const failures = [];

for (const item of required) {
  if (!fs.existsSync(path.join(root, item))) failures.push(`缺少：${item}`);
}

const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
const app = fs.readFileSync(path.join(root, "js/app.js"), "utf8");
const contentCode = fs.readFileSync(path.join(root, "js/content.js"), "utf8");

if (!html.includes('name="viewport"')) failures.push("缺少手机端 viewport");
if (!html.includes('src="js/content.js"') || !html.includes('src="js/app.js"')) failures.push("脚本加载顺序不正确");
if (!app.includes('loading="${priority ? "eager" : "lazy"}"')) failures.push("未发现图片懒加载配置");
if (!app.includes("IntersectionObserver")) failures.push("未发现固定导航滚动状态逻辑");

const sandbox = { window: {} };
vm.runInNewContext(contentCode, sandbox);
const data = sandbox.window.SITE_CONTENT;
if (!data) failures.push("content.js 未导出 SITE_CONTENT");

const requiredSections = ["hero", "overview", "stats", "industries", "people", "opportunities", "updates", "youth", "footer", "navigation"];
for (const section of requiredSections) {
  if (!data?.[section]) failures.push(`内容配置缺少模块：${section}`);
}

if (data?.stats?.items?.length !== 4) failures.push("核心数据不是 4 项");
for (const [index, item] of (data?.stats?.items || []).entries()) {
  if (!item.year) failures.push(`第 ${index + 1} 项核心数据缺少年份/年份状态`);
}

const anchors = new Set((data?.navigation || []).map((item) => item.href.replace(/^#/, "")));
const renderedIds = new Set([...app.matchAll(/id=\\?"([a-z-]+)\\?"/g)].map((match) => match[1]));
for (const anchor of anchors) {
  if (!renderedIds.has(anchor)) failures.push(`导航锚点没有对应模块：#${anchor}`);
}

for (const [key, image] of Object.entries(data?.images || {})) {
  if (image.src && (/^(https?:|data:|\/)/i.test(image.src))) failures.push(`${key} 图片不是相对路径`);
  if (image.src && !fs.existsSync(path.join(root, image.src))) failures.push(`${key} 图片文件不存在：${image.src}`);
}

if (failures.length) {
  console.error(`验证失败（${failures.length} 项）`);
  failures.forEach((item) => console.error(`- ${item}`));
  process.exit(1);
}

console.log("验证通过：目录、模块、4项核心数据、年份状态、相对图片路径、导航锚点与懒加载配置均正常。");
