from pathlib import Path
from PIL import Image, ImageOps


ROOT = Path(__file__).resolve().parent.parent
SOURCE = Path(r"D:\网页素材")

SELECTIONS = [
    (
        SOURCE / "01_首页候选" / "QQMail_1787036463189.mp4_000011.801.png",
        ROOT / "assets" / "images" / "01_首页候选" / "hero-town-aerial.jpg",
        1920,
    ),
    (
        SOURCE / "02_竹产业" / "_DSC3277.JPG",
        ROOT / "assets" / "images" / "02_竹产业" / "bamboo-processing.jpg",
        2000,
    ),
    (
        SOURCE / "03_肉鸡养殖" / "QQMail_1787036463189.mp4_000137.220.png",
        ROOT / "assets" / "images" / "03_肉鸡养殖" / "chicken-standard-farming.jpg",
        1920,
    ),
    (
        SOURCE / "04_水产" / "QQMail_1787036463189.mp4_000147.470.png",
        ROOT / "assets" / "images" / "04_水产" / "aquaculture-aerial.jpg",
        1600,
    ),
    (
        SOURCE / "05_返乡创业" / "QQMail_1787036463189.mp4_000038.650.png",
        ROOT / "assets" / "images" / "05_返乡创业" / "returnee-project.jpg",
        1600,
    ),
    (
        SOURCE / "06_人物" / "燕归来合作社返乡创业者——黄秀燕 (2).JPG",
        ROOT / "assets" / "images" / "06_人物" / "huang-xiuyan.jpg",
        1400,
    ),
    (
        SOURCE / "07_团队实践" / "_DSC4012.JPG",
        ROOT / "assets" / "images" / "07_团队实践" / "youth-livestream.jpg",
        2000,
    ),
]

for source, target, max_width in SELECTIONS:
    target.parent.mkdir(parents=True, exist_ok=True)
    with Image.open(source) as image:
        image = ImageOps.exif_transpose(image).convert("RGB")
        if image.width > max_width:
            height = round(image.height * max_width / image.width)
            image = image.resize((max_width, height), Image.Resampling.LANCZOS)
        image.save(target, "JPEG", quality=86, optimize=True, progressive=True)
    print(f"{target.relative_to(ROOT)}\t{target.stat().st_size}")
