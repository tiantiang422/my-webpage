from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageOps


SOURCE = Path(r"D:\网页素材")
OUTPUT = Path(r"C:\Users\10843\AppData\Local\Temp\lezhu-contact-sheets")
OUTPUT.mkdir(parents=True, exist_ok=True)


def sheet(folder_name: str, columns: int = 3) -> None:
    folder = SOURCE / folder_name
    files = sorted(
        p for p in folder.iterdir() if p.suffix.lower() in {".jpg", ".jpeg", ".png"}
    )
    thumb_w, thumb_h, label_h = 440, 248, 52
    rows = (len(files) + columns - 1) // columns
    canvas = Image.new("RGB", (columns * thumb_w, rows * (thumb_h + label_h)), "white")
    draw = ImageDraw.Draw(canvas)
    font = ImageFont.load_default()

    for index, file in enumerate(files):
        with Image.open(file) as source:
            source = ImageOps.exif_transpose(source).convert("RGB")
            thumb = ImageOps.fit(source, (thumb_w, thumb_h), method=Image.Resampling.LANCZOS)
        x = (index % columns) * thumb_w
        y = (index // columns) * (thumb_h + label_h)
        canvas.paste(thumb, (x, y))
        draw.rectangle((x, y + thumb_h, x + thumb_w, y + thumb_h + label_h), fill="#ffffff")
        draw.text((x + 10, y + thumb_h + 8), f"{index + 1:02d}  {file.name}", fill="#111111", font=font)
        draw.text((x + 10, y + thumb_h + 27), folder_name, fill="#666666", font=font)

    target = OUTPUT / f"{folder_name}.jpg"
    canvas.save(target, quality=88)
    print(target)


for name in ["01_首页候选", "02_竹产业", "03_肉鸡养殖", "04_水产", "05_返乡创业", "06_人物", "07_团队实践"]:
    sheet(name)
